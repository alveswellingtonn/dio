package com.wellington.diospringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DioSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
