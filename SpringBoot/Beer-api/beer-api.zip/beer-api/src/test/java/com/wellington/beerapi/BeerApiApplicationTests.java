package com.wellington.beerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
